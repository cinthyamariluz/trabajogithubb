package com.connnnnnnnnnnnnnnnnnental.trabajogithub;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajogithubApplicationTests {

	@Test
	void contextLoads() {
	}

}
