package com.connnnnnnnnnnnnnnnnnental.trabajogithub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrabajogithubApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrabajogithubApplication.class, args);
	}

}
